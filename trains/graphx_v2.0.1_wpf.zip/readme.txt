﻿GraphX for .NET library
http://panthernet.ru/en/projects-en/graphx-en
http://graphx.codeplex.com

Thanks for reading this! :)
You can find help and updates on the URL specified above.