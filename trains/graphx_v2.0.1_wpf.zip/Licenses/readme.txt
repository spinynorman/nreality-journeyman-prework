﻿Projects and code that uses Microsoft Public License:
 - NodeXL
 - WPFExtensions
 - Extended WPF Toolkit
 - Quickgraph

Projects and code that uses Apache 2.0 license:
- Graph#
- GraphX

Projects and code that uses The MIT License:
 - YAXLib